const express = require('express')
const dotenv = require('dotenv')
const nodemon = require('nodemon')
const cors = require('cors')
const pg = require('pg')

const app = new express()

app.use(cors())
app.use(express.json())

const users = [
  {
    username: 'test',
    password: 'test',
    name: 'Testiculus',
    lastname: 'Maximus',
    posts: 0,
    image: ''
  }
]
const posts = []

app.post('/login', (req, res) => {
  try {
    const username = req.body.user?.username
    const password = req.body.user?.password

    const foundUser = users.find(el => el.username === username)

    if (foundUser && foundUser.password === password) return res.status(200).send(foundUser)
    return res.status(401).send('Wrong data')
  } catch (err) {
    console.log(err)
    res.status(500).send(err)
  }
})

app.patch('/edit-user', (req, res) => {
  try {
    const username = req.body.user?.username
    const password = req.body.user?.password

    const foundUser = users.find(el => el.username === username)

    if (foundUser && foundUser.password === password) {
      const newUser = req.body.user
      console.log(users.indexOf(foundUser))
      users[users.indexOf(foundUser)] = newUser
      console.log(users)
      return res.status(200).send(newUser)
    }
    return res.status(401).send('Wrong data')
  } catch (err) {
    console.log(err)
    res.status(500).send(err)
  }
})


app.get('/posts', (req, res) => {
  try {
    return res.status(200).send(posts)
  } catch (err) {
    console.log(err)
    res.status(500).send(err)
  }
})

app.post('/post', (req, res) => {
  try {
    const username = req.body.user?.username
    const password = req.body.user?.password

    const foundUser = users.find(el => el.username === username)
    users[users.indexOf(foundUser)].posts++

    const post = req.body.post
    post.id = Date.now()
    post.date = new Date().toDateString()
    post.author = username

    posts.push(post)

    return res.status(200).send(post)
  } catch (err) {
    console.log(err)
    res.status(500).send(err)
  }
})


app.delete('/post', (req, res) => {
  try {
    const username = req.body.user?.username
    const password = req.body.user?.password

    const foundUser = users.find(el => el.username === username)

    const post = posts.find(el => el.id === Number(req.body.post.id))
    if (!post) return res.status(404).send('Post not found')
    if (post.author !== username) return res.status(403).send('This is not your post')
    users[users.indexOf(foundUser)].posts--
    posts.splice(posts.indexOf(post), 1)
    return res.status(200).send(posts)
  } catch (err) {
    console.log(err)
    res.status(500).send(err)
  }
})

app.listen(3005, () => { console.log('Server running on :3005') })